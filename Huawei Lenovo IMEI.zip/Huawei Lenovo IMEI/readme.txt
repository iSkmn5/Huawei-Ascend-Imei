
Note: device must be rooted!


Extract files within IMEI folder to C:\Documentes and Settings\User\ on your computer

Open a command prompt
---------------------
-Press windows key + R
-In the run box type in cmd
-press enter
-A black window will appear with writing

-Enter the following text:
imei.exe <15digit_IMEI_1> <15digit_IMEI_2>

(eg: imei.exe 123456789111111 123456789111111)

Press Enter          


If both IMEI you gave are in correct format the file named MP0B_001_NEW will 
be created. Now you can put it on the sd and insert that in to the phone.

Run root explorer
Copy it to - system need r/w need to be on: 
/data/nvram/md/NVRAM/NVD_IMEI/MP0B_001